##Changelog For AppleSimulatorUtils

##### 19-Sept-2017 16:38

* Improve filtering logic

##### 19-Sept-2017 14:58

* Add `--list` option to utils, with optional filter
* Sort devices by OS version (descending) then by name (ascending)

